
# 0.4.0.0
HBLAS now implements every single blas routine. Thanks to the contributors who
make this possible. This release disables level1 routines for now


# 0.3.1.1
release, bug fixes in show and improved tests, thanks to tomas musil for catching them

# 0.3.1.0
Improved type exports and getting started docs thanks to Stephen Diehl


#0.3.0.0

the first useful release

# PRE-RELEASE version 0.2.0.0
* Support for all BLAS operations defined on General Dense matrices,
both row and column major.
*  general dense linear and least squares solvers from LAPACK. Simple Drivers.

# version 0.1.0.0
* support basic manipulations of BLAS style dense matrices
