 DGTCON Example Program Results

 Estimate of condition number =   9.27E+01
