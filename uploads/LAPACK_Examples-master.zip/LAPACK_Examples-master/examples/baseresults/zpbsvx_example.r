 ZPBSVX Example Program Results

 Solution(s)
                    1                 2
 1  (-1.0000, 8.0000) ( 5.0000,-6.0000)
 2  ( 2.0000,-3.0000) ( 2.0000, 3.0000)
 3  (-4.0000,-5.0000) (-8.0000, 4.0000)
 4  ( 7.0000, 6.0000) (-1.0000,-7.0000)

 Backward errors (machine-dependent)
       1.0E-16    1.1E-16

 Estimated forward error bounds (machine-dependent)
       3.6E-14    3.4E-14

 Estimate of reciprocal condition number
       7.6E-03

 A has not been equilibrated
