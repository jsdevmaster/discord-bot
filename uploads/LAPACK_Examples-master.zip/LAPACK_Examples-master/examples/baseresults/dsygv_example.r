 DSYGV Example Program Results

 Eigenvalues
       -2.2254    -0.4548     0.1001     1.1270

 Eigenvectors
             1          2          3          4
 1      0.0690    -0.3080    -0.4469     0.5528
 2      0.5740    -0.5329    -0.0371     0.6766
 3      1.5428     0.3496     0.0505     0.9276
 4     -1.4004     0.6211     0.4743    -0.2510

 Estimate of reciprocal condition number for B
        5.8E-03

 Error estimates for the eigenvalues
        9.3E-14    2.5E-14    1.1E-14    5.1E-14

 Error estimates for the eigenvectors
        1.0E-13    2.1E-13    1.8E-13    1.4E-13
