 DPPSVX Example Program Results

 Solution(s)
             1          2
 1      1.0000     4.0000
 2     -1.0000     3.0000
 3      2.0000     2.0000
 4     -3.0000     1.0000

 Backward errors (machine-dependent)
       6.7E-17    7.9E-17

 Estimated forward error bounds (machine-dependent)
       2.3E-14    2.3E-14

 Estimate of reciprocal condition number
       1.0E-02

 A has not been equilibrated
