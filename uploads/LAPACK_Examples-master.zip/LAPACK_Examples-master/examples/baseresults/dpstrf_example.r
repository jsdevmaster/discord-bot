 DPSTRF Example Program Results

 Computed rank:   3

 Factor
             1          2          3          4          5
 1      2.8671
 2      1.4091     0.7242
 3      2.5741    -0.3965     0.5262
 4      0.9348     0.0315    -0.2920     0.0000
 5      0.8510     0.1254    -0.0018     0.0000     0.0000

 PIV
             2          1          3          4          5
