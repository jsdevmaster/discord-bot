 DGTSV Example Program Results

 Solution
     -4.0000     7.0000     3.0000    -4.0000    -3.0000
