 DSPTRF Example Program Results

 Details of factorization
             1          2          3          4
 1      2.0700
 2      4.2000     1.1500
 3      0.2230     0.8115    -2.5907
 4      0.6537    -0.5960     0.3031     0.4074

 IPIV
            -3         -3          3          4
