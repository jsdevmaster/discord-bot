 DGEEVX Example Program Results

 Eigenvalues

          Eigenvalue           rcond    error
  1   7.9948E-01               0.9936    -
  2 (-9.9412E-02, 4.0079E-01)  0.7027    -
  3 (-9.9412E-02,-4.0079E-01)  0.7027    -
  4  -1.0066E-01               0.5710    -

 Eigenvectors

          Eigenvector          rcond    error

  1   6.5509E-01               0.8181    -
      5.2363E-01
     -5.3622E-01
      9.5607E-02

  2 (-1.9330E-01, 2.5463E-01)  0.3996    -
    ( 2.5186E-01,-5.2240E-01)
    ( 9.7182E-02,-3.0838E-01)
    ( 6.7595E-01, 0.0000E+00)

  3 (-1.9330E-01,-2.5463E-01)  0.3996    -
    ( 2.5186E-01, 5.2240E-01)
    ( 9.7182E-02, 3.0838E-01)
    ( 6.7595E-01,-0.0000E+00)

  4   1.2533E-01               0.3125    -
      3.3202E-01
      5.9384E-01
      7.2209E-01

 Errors below 10*machine precision are not displayed
