 DSTEV Example Program Results

 Eigenvalues
     0.6476  3.5470  8.6578 17.1477
 Eigenvectors
          1       2       3       4
 1   0.9396  0.3388  0.0494  0.0034
 2  -0.3311  0.8628  0.3781  0.0545
 3   0.0853 -0.3648  0.8558  0.3568
 4  -0.0167  0.0879 -0.3497  0.9326

 Error estimate for the eigenvalues
        3.8E-15

 Error estimates for the eigenvectors
        1.3E-15    1.3E-15    7.5E-16    4.5E-16
