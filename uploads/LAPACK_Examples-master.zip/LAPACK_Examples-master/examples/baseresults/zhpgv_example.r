 ZHPGV Example Program Results

 Eigenvalues
       -5.9990    -2.9936     0.5047     3.9990

 Estimate of reciprocal condition number for B
        2.5E-03

 Error estimates for the eigenvalues
        6.7E-13    4.1E-13    1.9E-13    5.0E-13
