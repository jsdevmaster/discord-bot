 DSTEVR Example Program Results

 Selected eigenvalues
     3.5470  8.6578
 Selected eigenvectors
          1       2
 1   0.3388  0.0494
 2   0.8628  0.3781
 3  -0.3648  0.8558
 4   0.0879 -0.3497
