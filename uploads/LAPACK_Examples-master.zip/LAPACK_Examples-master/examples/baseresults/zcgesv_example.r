 ZCGESV Example Program Results

 Solution
    ( 1.0000, 1.0000) ( 2.0000,-3.0000) (-4.0000,-5.0000) (-0.0000, 6.0000)

 Pivot indices
           3          2          3          4
