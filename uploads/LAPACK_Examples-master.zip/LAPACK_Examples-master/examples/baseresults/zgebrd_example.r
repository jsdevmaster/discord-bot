 ZGEBRD Example Program Results

 Diagonal
   -3.0870   2.0660   1.8731   2.0022
 Superdiagonal
    2.1126   1.2628  -1.6126
