 DSBEV Example Program Results

 Eigenvalues
    -3.2474 -2.6633  1.7511  4.1599 14.9997
 Eigenvectors
          1       2       3       4       5
 1   0.0394  0.6238  0.5635  0.5165  0.1582
 2   0.5721 -0.2575 -0.3896  0.5955  0.3161
 3  -0.4372 -0.5900  0.4008  0.1470  0.5277
 4  -0.4424  0.4308 -0.5581 -0.0470  0.5523
 5   0.5332  0.1039  0.2421 -0.5956  0.5400

 Error estimate for the eigenvalues
        3.3E-15

 Error estimates for the eigenvectors
        5.7E-15    5.7E-15    1.4E-15    1.4E-15    3.1E-16
