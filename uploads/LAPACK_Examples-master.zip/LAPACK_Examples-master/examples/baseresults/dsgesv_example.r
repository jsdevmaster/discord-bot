 DSGESV Example Program Results

 Solution
        1.0000    -1.0000     3.0000    -5.0000

 Pivot indices
             2          2          3          4
