 DPBEQU Example Program Results

 Matrix A
               1            2            3            4
 1    5.4900E+00   2.6800E+10
 2                 5.6300E+20  -2.3900E+10
 3                              2.6000E+00  -2.2200E+00
 4                                           5.1700E+00

 SCOND = 6.8E-11, AMAX = 5.6E+20

 Diagonal scaling factors
     4.3E-01    4.2E-11    6.2E-01    4.4E-01

 Scaled matrix
             1          2          3          4
 1      1.0000     0.4821
 2                 1.0000    -0.6247
 3                            1.0000    -0.6055
 4                                       1.0000
