 DTZRZF Example Program Results

 Tolerance used to estimate the rank of A
        1.00E-02
 Estimated rank of A
        4

 Least squares solution(s)
             1          2
 1      0.6344     3.6258
 2      0.9699     1.8284
 3     -1.4402    -1.6416
 4      3.3678     2.4307
 5      3.3992     0.2818

 Square root(s) of the residual sum(s) of squares
        2.54E-02   3.65E-02
