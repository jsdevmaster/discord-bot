 DPTSVX Example Program Results

 Solution(s)
             1          2
 1      2.5000     2.0000
 2      2.0000    -1.0000
 3      1.0000    -3.0000
 4     -1.0000     6.0000
 5      3.0000    -5.0000

 Backward errors (machine-dependent)
     0.0E+00    7.4E-17

 Estimated forward error bounds (machine-dependent)
     2.4E-14    4.7E-14

 Estimate of reciprocal condition number
     9.5E-03
