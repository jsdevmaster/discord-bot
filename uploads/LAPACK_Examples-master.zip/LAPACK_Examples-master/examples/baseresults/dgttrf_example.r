 DGTTRF Example Program Results

 Details of factorization

  Second superdiagonal of U
   -1.0000   1.9000   8.0000

  First superdiagonal of U
    2.3000  -5.0000  -0.9000   7.1000

  Main diagonal of U
    3.4000   3.6000   7.0000  -6.0000  -1.0154

  Multipliers
    0.8824   0.0196   0.1401  -0.0148

  Vector of interchanges
         2        3        4        5        5
