 ZGEQP3 Example Program Results

 Tolerance used to estimate the rank of A
      1.00E-02
 Estimated rank of A
        3

 Least squares solution(s)
                    1                 2
 1  ( 0.0000, 0.0000) ( 0.0000, 0.0000)
 2  ( 2.7020, 8.0911) (-2.2682,-2.9884)
 3  ( 2.8888, 2.5012) ( 0.9779, 1.3565)
 4  ( 2.7100, 0.4791) (-1.3734, 0.2212)

 Square root(s) of the residual sum(s) of squares
      2.51E-01   8.10E-02
