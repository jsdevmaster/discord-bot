 ZGESVD Example Program Results

 Singular values of A:
         3.9994        3.0003        1.9944        0.9995

 Least squares solution:
    ( -0.0719, -0.2761)
    (  0.6796,  0.4326)
    ( -0.3832, -0.5447)
    (  0.0096, -0.3489)

 Norm of Residual:
         1.5266
