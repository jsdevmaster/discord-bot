 ZPTRFS Example Program Results

 Solution(s)
                    1                 2
 1  ( 2.0000, 1.0000) (-3.0000,-2.0000)
 2  ( 1.0000, 1.0000) ( 1.0000, 1.0000)
 3  ( 1.0000,-2.0000) ( 1.0000,-2.0000)
 4  ( 1.0000,-1.0000) ( 2.0000, 1.0000)

 Backward errors (machine-dependent)
       0.0E+00    0.0E+00

 Estimated forward error bounds (machine-dependent)
       9.0E-12    6.1E-12
