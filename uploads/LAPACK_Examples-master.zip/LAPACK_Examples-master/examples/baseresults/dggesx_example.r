 DGGESX Example Program Results

 Matrix A
             1          2          3          4
 1      3.9000    12.5000   -34.5000    -0.5000
 2      4.3000    21.5000   -47.5000     7.5000
 3      4.3000    21.5000   -43.5000     3.5000
 4      4.4000    26.0000   -46.0000     6.0000

 Matrix B
             1          2          3          4
 1      1.0000     2.0000    -3.0000     1.0000
 2      1.0000     3.0000    -5.0000     4.0000
 3      1.0000     3.0000    -4.0000     3.0000
 4      1.0000     3.0000    -4.0000     4.0000

 Number of eigenvalues for which SELCTG is true =    2
 (dimension of deflating subspaces)

 Selected generalized eigenvalues
    1     (  2.000,  0.000)
    2     (  4.000,  0.000)

 Reciprocals of left and right projection norms onto
 the deflating subspaces for the selected eigenvalues
 RCONDE(1) =  1.9E-01, RCONDE(2) =  1.8E-02

 Reciprocal condition numbers for the left and right
 deflating subspaces
 RCONDV(1) =  5.4E-02, RCONDV(2) =  9.0E-02

 Approximate asymptotic error bound for selected eigenvalues    =  1.1E-13
 Approximate asymptotic error bound for the deflating subspaces =  2.4E-13
