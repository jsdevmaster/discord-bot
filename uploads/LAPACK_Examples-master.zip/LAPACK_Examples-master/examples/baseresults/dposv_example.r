 DPOSV Example Program Results

 Solution
        1.0000    -1.0000     2.0000    -3.0000

 Cholesky factor U
             1          2          3          4
 1      2.0396    -1.5297     0.2746    -0.0490
 2                 1.6401    -0.2500     0.6737
 3                            0.7887     0.6617
 4                                       0.5347
