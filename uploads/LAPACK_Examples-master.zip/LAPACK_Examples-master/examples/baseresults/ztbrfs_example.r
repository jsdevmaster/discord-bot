 ZTBRFS Example Program Results

 Solution(s)
                    1                 2
 1  ( 0.0000, 2.0000) ( 1.0000, 5.0000)
 2  ( 1.0000,-3.0000) (-7.0000,-2.0000)
 3  (-4.0000,-5.0000) ( 3.0000, 4.0000)
 4  ( 2.0000,-1.0000) (-6.0000,-9.0000)

 Backward errors (machine-dependent)
         4.1E-17           4.2E-17
 Estimated forward error bounds (machine-dependent)
         1.8E-14           2.2E-14
