 DPOTRF Example Program Results

 Factor
             1          2          3          4
 1      2.0396
 2     -1.5297     1.6401
 3      0.2746    -0.2500     0.7887
 4     -0.0490     0.6737     0.6617     0.5347
