 ZGECON Example Program Results

 Estimate of condition number =  1.50E+02
