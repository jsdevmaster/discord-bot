 ZPOCON Example Program Results

 Estimate of condition number =  1.51E+02
