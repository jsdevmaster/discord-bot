 ZPBRFS Example Program Results

 Solution(s)
                    1                 2
 1  (-1.0000, 8.0000) ( 5.0000,-6.0000)
 2  ( 2.0000,-3.0000) ( 2.0000, 3.0000)
 3  (-4.0000,-5.0000) (-8.0000, 4.0000)
 4  ( 7.0000, 6.0000) (-1.0000,-7.0000)

 Backward errors (machine-dependent)
         8.2E-17           8.3E-17
 Estimated forward error bounds (machine-dependent)
         3.5E-14           3.2E-14
