 DSBGVX Example Program Results

 Number of eigenvalues found =    1

 Eigenvalues
     0.0992
 Selected eigenvectors
          1
 1   0.6729
 2  -0.1009
 3   0.0155
 4  -0.3806
