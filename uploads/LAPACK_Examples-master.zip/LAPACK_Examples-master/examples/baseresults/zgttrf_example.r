 ZGTTRF Example Program Results

 Details of factorization

  Second superdiagonal of U
 (  2.0000,  1.0000) ( -1.0000,  1.0000) (  1.0000, -1.0000)

  First superdiagonal of U
 ( -1.3000,  1.3000) ( -1.3000,  3.3000) ( -0.3000,  4.3000) ( -3.3000,  1.3000)

  Main diagonal of U
 (  1.0000, -2.0000) (  1.0000,  1.0000) (  2.0000, -3.0000) (  1.0000,  1.0000)
 ( -1.3399,  0.2875)

  Multipliers
 ( -0.7800, -0.2600) (  0.1620, -0.4860) ( -0.0452, -0.0010) ( -0.3979, -0.0562)

  Vector of interchanges
       2      3      4      5      5
