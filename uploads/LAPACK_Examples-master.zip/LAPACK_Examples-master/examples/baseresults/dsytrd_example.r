 DSYTRD Example Program Results

 Diagonal and off-diagonal elements of tridiagonal form

     i         D            E
     1      2.07000      5.82575
     2      1.47409      2.62405
     3     -0.64916      0.91627
     4     -1.69493
