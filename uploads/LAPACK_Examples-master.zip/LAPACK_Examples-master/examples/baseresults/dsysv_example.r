 DSYSV Example Program Results

 Solution
       -5.0000    -2.0000     1.0000     4.0000

 Details of the factorization
             1          2          3          4
 1      0.4074     0.3031    -0.5960     0.6537
 2                -2.5907     0.8115     0.2230
 3                            1.1500     4.2000
 4                                       2.0700

 Pivot indices
           1          2         -2         -2
