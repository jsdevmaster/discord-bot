 ZGERFS Example Program Results

 Solution(s)
                    1                 2
 1  ( 1.0000, 1.0000) (-1.0000,-2.0000)
 2  ( 2.0000,-3.0000) ( 5.0000, 1.0000)
 3  (-4.0000,-5.0000) (-3.0000, 4.0000)
 4  (-0.0000, 6.0000) ( 2.0000,-3.0000)

 Backward errors (machine-dependent)
         5.5E-17           6.3E-17
 Estimated forward error bounds (machine-dependent)
         5.8E-14           7.9E-14
