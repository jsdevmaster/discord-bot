 DBDSVDX Example Program Results

  3 singular values of B in the range [  0.000,  4.000]:
         3.0006        1.9960        0.9998
