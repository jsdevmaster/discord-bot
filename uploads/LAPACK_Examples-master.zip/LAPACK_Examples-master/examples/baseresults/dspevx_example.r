 DSPEVX Example Program Results

 Number of eigenvalues found =    2

 Eigenvalues
    -0.5146 -0.2943
 Selected eigenvectors
          1       2
 1  -0.5144 -0.2767
 2   0.4851  0.6634
 3   0.5420 -0.6504
 4  -0.4543  0.2457
