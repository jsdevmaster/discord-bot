 DGESVDX Example Program Results

 Singular values of A:
         3.6831        1.3569

 Estimates given as multiples of machine precision
 Error estimate for the singular values
              4

 Error estimates for the left singular vectors
              2          3

 Error estimates for the right singular vectors
              2          2
