 ZGESVX Example Program Results

 Solution(s)
                    1                 2
 1  ( 1.0000, 1.0000) (-1.0000,-2.0000)
 2  ( 2.0000,-3.0000) ( 5.0000, 1.0000)
 3  (-4.0000,-5.0000) (-3.0000, 4.0000)
 4  ( 0.0000, 6.0000) ( 2.0000,-3.0000)

 Backward errors (machine-dependent)
       5.3E-17    8.4E-17

 Estimated forward error bounds (machine-dependent)
       5.7E-14    7.7E-14

 A has been row scaled as diag(R)*A

 Reciprocal condition number estimate of scaled matrix
       1.0E-02

 Estimate of reciprocal pivot growth factor
       8.3E-01
