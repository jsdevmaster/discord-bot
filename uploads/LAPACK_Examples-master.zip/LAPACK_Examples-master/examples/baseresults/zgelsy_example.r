 ZGELSY Example Program Results

 Least squares solution
 ( 1.1669,-3.3224) ( 1.3486, 5.5027) ( 4.1764, 2.3435) ( 0.6467, 0.0107)

 Tolerance used to estimate the rank of A
   1.00E-02
 Estimated rank of A
      3
