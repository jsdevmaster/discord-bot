 DBDSDC Example Program Results

 Singular values of B:
         4.0001        3.0006        1.9960        0.9998
