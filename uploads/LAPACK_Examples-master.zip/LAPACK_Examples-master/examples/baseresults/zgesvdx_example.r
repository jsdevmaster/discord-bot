 ZGESVDX Example Program Results

 Singular values of A:
         3.9994        3.0003        1.9944

 Error estimates (as multiples of machine precision):
   for the singular values
              4

   for the left singular vectors
              4          4          4

   for the right singular vectors
              4          4          4
