 DGGRQF Example Program Results

 Constrained least squares solution
      0.4890     0.9975     0.4890     0.9975

 Square root of the residual sum of squares
      2.51E-02
