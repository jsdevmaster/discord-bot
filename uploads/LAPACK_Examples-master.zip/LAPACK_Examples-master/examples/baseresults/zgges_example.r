 ZGGES Example Program Results

 Generalized Eigenvalues
  1   (  3.00, -9.00)
  2   (  4.00, -5.00)
  3   (  2.00, -5.00)
  4   (  3.00, -1.00)
