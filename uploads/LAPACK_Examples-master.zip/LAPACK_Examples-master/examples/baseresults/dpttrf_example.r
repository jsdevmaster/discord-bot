 DPTTRF Example Program Results

 Details of factorization

  The diagonal elements of D
    4.0000   9.0000  25.0000  16.0000   1.0000

  Subdiagonal elements of the Cholesky factor L
   -0.5000  -0.6667   0.6000   0.5000
