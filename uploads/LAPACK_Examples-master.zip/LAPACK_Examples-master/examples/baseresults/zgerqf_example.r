 ZGERQF Example Program Results

 Minimum-norm solution
 ( -2.8501,  6.4683) (  1.6264, -0.7799) (  6.9290,  4.6481) (  1.4048,  3.2400)
