 DSBEVX Example Program Results

 Number of eigenvalues found =    2

 Eigenvalues
    -2.6633  1.7511
 Selected eigenvectors
          1       2
 1  -0.6238 -0.5635
 2   0.2575  0.3896
 3   0.5900 -0.4008
 4  -0.4308  0.5581
 5  -0.1039 -0.2421
