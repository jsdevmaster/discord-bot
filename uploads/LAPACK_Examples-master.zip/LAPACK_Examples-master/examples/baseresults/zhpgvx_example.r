 ZHPGVX Example Program Results

 Number of eigenvalues found =    2

 Eigenvalues
    -2.9936  0.5047
 Selected eigenvectors
          1       2
 1  -0.6626  0.2835
     0.2258 -0.5806
 
 2  -0.1164 -0.3769
    -0.0178 -0.3194
 
 3   0.9098 -0.3338
    -0.0000 -0.0134
 
 4  -0.6120  0.6663
    -0.5348  0.0000
