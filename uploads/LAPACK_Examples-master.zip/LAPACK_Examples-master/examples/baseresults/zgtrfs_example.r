 ZGTRFS Example Program Results

 Solution(s)
                    1                 2
 1  ( 1.0000, 1.0000) ( 2.0000,-1.0000)
 2  ( 3.0000,-1.0000) ( 1.0000, 2.0000)
 3  ( 4.0000, 5.0000) (-1.0000, 1.0000)
 4  (-1.0000,-2.0000) ( 2.0000, 1.0000)
 5  ( 1.0000,-1.0000) ( 2.0000,-2.0000)

 Backward errors (machine-dependent)
       2.2E-17    1.0E-16

 Estimated forward error bounds (machine-dependent)
       5.3E-14    7.7E-14
