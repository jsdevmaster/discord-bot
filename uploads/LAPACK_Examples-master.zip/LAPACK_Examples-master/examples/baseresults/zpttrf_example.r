 ZPTTRF Example Program Results

 Details of factorization

  The diagonal elements of D
   16.0000   9.0000   1.0000   4.0000

  Subdiagonal elements of the Cholesky factor L
    1.0000   1.0000   2.0000  -1.0000   1.0000  -4.0000
