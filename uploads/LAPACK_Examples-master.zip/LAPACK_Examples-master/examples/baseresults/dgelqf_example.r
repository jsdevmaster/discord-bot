 DGELQF Example Program Results

 Minimum-norm solution(s)
             1          2
 1      0.2371     0.7383
 2     -0.4575     0.0158
 3     -0.0085    -0.0161
 4     -0.5192     1.0768
 5      0.0239    -0.6436
 6     -0.0543    -0.6613
