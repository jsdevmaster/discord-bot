 DPBRFS Example Program Results

 Solution(s)
             1          2
 1      5.0000    -2.0000
 2     -2.0000     6.0000
 3     -3.0000    -1.0000
 4      1.0000     4.0000

 Backward errors (machine-dependent)
       4.4E-17    9.2E-17
 Estimated forward error bounds (machine-dependent)
       2.0E-14    2.9E-14
