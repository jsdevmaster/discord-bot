 ZTBCON Example Program Results

 Estimate of condition number =  3.35E+01
