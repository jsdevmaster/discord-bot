 DSYCON Example Program Results

 Estimate of condition number =  7.57E+01
