 DTRSNA Example Program Results

 S
       9.9E-01    7.0E-01    7.0E-01    5.7E-01

 SEP
       6.3E-01    3.7E-01    3.7E-01    3.1E-01

 Approximate error estimates for eigenvalues of T (machine-dependent)
       1.9E-16    2.7E-16    2.7E-16    3.4E-16

 Approximate error estimates for right eigenvectors of T (machine-dependent)
       3.1E-16    5.1E-16    5.1E-16    6.1E-16
