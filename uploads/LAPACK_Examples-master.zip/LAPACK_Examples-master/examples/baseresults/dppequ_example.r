 DPPEQU Example Program Results

 Matrix A
               1            2            3            4
 1    4.1600E+00  -3.1200E+05   5.6000E-01  -1.0000E-01
 2                 5.0300E+10  -8.3000E+04   1.1800E+05
 3                              7.6000E-01   3.4000E-01
 4                                           1.1800E+00

 SCOND = 3.9E-06, AMAX = 5.0E+10

 Diagonal scaling factors
     4.9E-01    4.5E-06    1.1E+00    9.2E-01

 Scaled matrix
             1          2          3          4
 1      1.0000    -0.6821     0.3149    -0.0451
 2                 1.0000    -0.4245     0.4843
 3                            1.0000     0.3590
 4                                       1.0000
