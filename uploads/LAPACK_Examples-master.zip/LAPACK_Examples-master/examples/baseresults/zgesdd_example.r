 ZGESDD Example Program Results

 Singular values of A:
         3.9994        3.0003        1.9944        0.9995

 Minimum norm solution:
    ( -0.4024,  0.3777)
    ( -0.2272,  0.3626)
    (  0.1704, -0.1532)
    (  0.2125,  0.0781)
    (  0.2041,  0.2236)
    (  0.2766, -0.1517)

 Norm of Solution:
         0.8846

 Norm of Residual:
         0.0000
