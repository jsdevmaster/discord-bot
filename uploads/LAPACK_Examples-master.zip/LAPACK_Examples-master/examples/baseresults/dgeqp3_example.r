 DGEQP3 Example Program Results

 Tolerance used to estimate the rank of A
        1.00E-02
 Estimated rank of A
        4

 Least squares solution(s)
             1          2
 1      0.9767     4.0159
 2      1.9861     2.9867
 3      0.0000     0.0000
 4      2.9927     2.0032
 5      4.0272     0.9976

 Square root(s) of the residual sum(s) of squares
        2.54E-02   3.65E-02
