 DSBGST Example Program Results

 Eigenvalues
    -0.8305 -0.6401  0.0992  1.8525
