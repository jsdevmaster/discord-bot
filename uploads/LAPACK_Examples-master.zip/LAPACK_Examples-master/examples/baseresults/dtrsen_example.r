 DTRSEN Example Program Results

 Matrix A computed from Q*T*Q^T
          1       2       3       4
 1   0.3500  0.4500 -0.1400 -0.1700
 2   0.0900  0.0700 -0.5399  0.3500
 3  -0.4400 -0.3300 -0.0300  0.1700
 4   0.2500 -0.3200 -0.1300  0.1100

 Condition number estimate of the selected cluster of eigenvalues =   1.75E+00

 Condition number estimate of the specified invariant subspace    =   3.22E+00
