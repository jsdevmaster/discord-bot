 DPTCON Example Program Results

 Estimate of condition number =   1.05E+02
