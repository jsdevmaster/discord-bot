 DGESVD Example Program Results

 Singular values of A:
         9.9966        3.6831        1.3569        0.5000

 Least squares solution:
        -0.0563       -0.1700        0.8202        0.5545

 Norm of Residual:
         1.7472
