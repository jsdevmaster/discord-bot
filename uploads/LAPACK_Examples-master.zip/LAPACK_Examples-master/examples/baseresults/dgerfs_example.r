 DGERFS Example Program Results

 Solution(s)
             1          2
 1      1.0000     3.0000
 2     -1.0000     2.0000
 3      3.0000     4.0000
 4     -5.0000     1.0000

 Backward errors (machine-dependent)
       9.4E-17    3.7E-17
 Estimated forward error bounds (machine-dependent)
       2.4E-14    3.3E-14
