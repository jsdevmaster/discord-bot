 DSYTRI Example Program Results

 Inverse
             1          2          3          4
 1      0.7485
 2      0.5221    -0.1605
 3     -1.0058    -0.3131     1.3501
 4     -1.4386    -0.7440     2.0667     2.4547
