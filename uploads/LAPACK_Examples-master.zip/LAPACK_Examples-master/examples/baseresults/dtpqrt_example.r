 DTPQRT Example Program Results

 solution(s) for n rows
             1          2
 1      1.5179    -1.5850
 2      1.8629     0.5531
 3     -1.4608     1.3485
 4      0.0398     2.9619

 Least squares solution(s) for all rows
             1          2
 1      1.5339    -1.5753
 2      1.8707     0.5559
 3     -1.5241     1.3119
 4      0.0392     2.9585

 Square root(s) of the residual sum(s) of squares
        2.22E-02   1.38E-02
