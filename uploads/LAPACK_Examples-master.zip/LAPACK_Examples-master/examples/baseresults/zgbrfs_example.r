 ZGBRFS Example Program Results

 Solution(s)
                    1                 2
 1  (-3.0000, 2.0000) ( 1.0000, 6.0000)
 2  ( 1.0000,-7.0000) (-7.0000,-4.0000)
 3  (-5.0000, 4.0000) ( 3.0000, 5.0000)
 4  ( 6.0000,-8.0000) (-8.0000, 2.0000)

 Backward errors (machine-dependent)
         2.7E-17           6.7E-17
 Estimated forward error bounds (machine-dependent)
         3.5E-14           4.3E-14
