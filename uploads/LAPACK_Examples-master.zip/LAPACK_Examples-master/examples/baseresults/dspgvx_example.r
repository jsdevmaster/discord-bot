 DSPGVX Example Program Results

 Number of eigenvalues found =    2

 Eigenvalues
    -0.4548  0.1001
 Selected eigenvectors
          1       2
 1  -0.3080 -0.4469
 2  -0.5329 -0.0371
 3   0.3496  0.0505
 4   0.6211  0.4743
