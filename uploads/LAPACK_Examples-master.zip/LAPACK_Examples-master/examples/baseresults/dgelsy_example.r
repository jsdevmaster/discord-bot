 DGELSY Example Program Results

 Least squares solution
      0.6344     0.9699    -1.4402     3.3678     3.3992

 Tolerance used to estimate the rank of A
      1.00E-02
 Estimated rank of A
      4
