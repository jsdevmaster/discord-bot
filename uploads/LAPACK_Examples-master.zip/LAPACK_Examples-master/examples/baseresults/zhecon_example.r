 ZHECON Example Program Results

 Estimate of condition number =  6.68E+00
