 ZGELSS Example Program Results

 Least squares solution
 ( 1.1673,-3.3222) ( 1.3480, 5.5028) ( 4.1762, 2.3434) ( 0.6465, 0.0105)

 Tolerance used to estimate the rank of A
      1.00E-02
 Estimated rank of A
      3

 Singular values of A
      2.9979     1.9983     1.0044     0.0064
