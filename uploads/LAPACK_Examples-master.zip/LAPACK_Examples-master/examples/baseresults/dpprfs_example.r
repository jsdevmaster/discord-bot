 DPPRFS Example Program Results

 Solution(s)
             1          2
 1      1.0000     4.0000
 2     -1.0000     3.0000
 3      2.0000     2.0000
 4     -3.0000     1.0000

 Backward errors (machine-dependent)
       5.1E-17    6.1E-17
 Estimated forward error bounds (machine-dependent)
       2.3E-14    2.3E-14
