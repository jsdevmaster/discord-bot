 ZPBCON Example Program Results

 Estimate of condition number =  1.32E+02
