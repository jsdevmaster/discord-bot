 DSYGVD Example Program Results

 Eigenvalues
       -3.5411    -0.3347     0.2983     2.2544
 Eigenvectors
             1          2          3          4
 1     -0.0356    -0.1039    -0.7459     0.1909
 2      0.3809     0.4322    -0.7845     0.3540
 3     -0.2943     1.5644    -0.7144     0.5665
 4     -0.3186    -1.0647     1.1184     0.3859

 Estimate of reciprocal condition number for B
        5.8E-03

 Error estimates for the eigenvalues
        1.4E-13    1.7E-14    1.6E-14    9.1E-14

 Error estimates for the eigenvectors
        5.6E-14    1.3E-13    1.3E-13    6.8E-14
