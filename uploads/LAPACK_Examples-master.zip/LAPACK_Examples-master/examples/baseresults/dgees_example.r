 DGEES Example Program Results

 Matrix A
          1       2       3       4
 1   0.3500  0.4500 -0.1400 -0.1700
 2   0.0900  0.0700 -0.5400  0.3500
 3  -0.4400 -0.3300 -0.0300  0.1700
 4   0.2500 -0.3200 -0.1300  0.1100

 Number of eigenvalues for which SELECT is true =    1
 (dimension of invariant subspace)

 Selected eigenvalues
  (  0.7995,  0.0000)

