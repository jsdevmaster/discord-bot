 DTRCON Example Program Results

 Estimate of condition number =  1.16E+02
