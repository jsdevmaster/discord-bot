 ZHPGVD Example Program Results

 Eigenvalues
      -61.7321    -6.6195     0.0725    43.1883

 Estimate of reciprocal condition number for B
        2.5E-03

 Error estimates (relative to machine precision)
 for the eigenvalues:
        2.4E+04    2.8E+03    2.3E+02    1.7E+04
