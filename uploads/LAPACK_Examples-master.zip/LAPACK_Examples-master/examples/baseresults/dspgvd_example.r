 DSPGVD Example Program Results

 Eigenvalues
       -3.5411    -0.3347     0.2983     2.2544

 Estimate of reciprocal condition number for B
        5.8E-03

 Error estimates for the eigenvalues
        1.4E-13    1.7E-14    1.6E-14    9.1E-14
