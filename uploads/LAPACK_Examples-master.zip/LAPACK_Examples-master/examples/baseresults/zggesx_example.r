 ZGGESX Example Program Results

 Number of eigenvalues for which SELCTG is true =    2
 (dimension of deflating subspaces)

 Selected generalized eigenvalues
  1 (  2.00, -5.00)
  2 (  3.00, -1.00)
