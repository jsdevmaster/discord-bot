 DGERQF Example Program Results

 Minimum-norm solution
    0.2371  -0.4575  -0.0085  -0.5192   0.0239  -0.0543
