 DPBSV Example Program Results

 Solution
        5.0000    -2.0000    -3.0000     1.0000

 Cholesky factor U
             1          2          3          4
 1      2.3431     1.1438
 2                 2.0789    -1.1497
 3                            1.1306    -1.9635
 4                                       1.1465
