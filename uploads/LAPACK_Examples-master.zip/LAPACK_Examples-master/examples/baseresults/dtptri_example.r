 DTPTRI Example Program Results

 Inverse
             1          2          3          4
 1      0.2326
 2     -0.1891    -0.2053
 3      0.0043    -0.0079    -0.1247
 4      0.8463    -0.2738    -6.1825     8.3333
