 ZTGSNA Example Program Results

 S
       1.0E+00    8.2E-01    7.2E-01    8.2E-01

 DIF
       3.2E-01    3.6E-01    5.5E-01    2.8E-01

 Approximate error estimates for eigenvalues of (A,B)
       3.0E-15    3.8E-15    4.3E-15    3.8E-15

 Approximate error estimates for right eigenvectors of (A,B)
       9.5E-15    8.6E-15    5.6E-15    1.1E-14
