 DSYGST Example Program Results

 Eigenvalues
    -2.2254 -0.4548  0.1001  1.1270
