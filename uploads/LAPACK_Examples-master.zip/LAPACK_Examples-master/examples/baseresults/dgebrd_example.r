 DGEBRD Example Program Results

 Diagonal
    3.6177   2.4161  -1.9213  -1.4265
 Superdiagonal
    1.2587   1.5262  -1.1895
