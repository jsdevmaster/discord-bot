 ZHBEVX Example Program Results

 Number of eigenvalues found =    2

 Eigenvalues
    -1.4094  1.4421
 Selected eigenvectors
          1       2
 1   0.6367  0.4516
     0.0000  0.0000
 
 2  -0.2578 -0.3029
     0.2413 -0.4402
 
 3  -0.3039  0.3160
    -0.3481  0.2978
 
 4   0.3450 -0.4088
    -0.0832 -0.3213
 
 5  -0.2469  0.0204
     0.2634  0.2262
