 DTRRFS Example Program Results

 Solution(s)
             1          2
 1     -3.0000    -5.0000
 2     -1.0000     1.0000
 3      2.0000    -1.0000
 4      1.0000     6.0000

 Backward errors (machine-dependent)
       6.9E-17    0.0E+00
 Estimated forward error bounds (machine-dependent)
       8.3E-14    2.6E-14
