 ZPTCON Example Program Results

 Estimate of condition number =   9.21E+03
