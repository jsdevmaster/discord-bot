 DTBRFS Example Program Results

 Solution(s)
             1          2
 1      4.0000     1.0000
 2     -1.0000    -3.0000
 3      3.0000     2.0000
 4      2.0000    -2.0000

 Backward errors (machine-dependent)
       4.7E-17    2.5E-17
 Estimated forward error bounds (machine-dependent)
       5.4E-14    5.8E-14
