 DSPEV Example Program Results

 Eigenvalues
    -2.0531 -0.5146 -0.2943 12.8621

 Error estimate for the eigenvalues
        2.9E-15
