 ZGTCON Example Program Results

 Estimate of condition number =   1.84E+02
