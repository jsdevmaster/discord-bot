 ZTRSEN Example Program Results

 Matrix A created from Q*T*Q^T
                    1                 2                 3                 4
 1  (-3.9702,-5.0406) (-4.1108, 3.7002) (-0.3403, 1.0098) ( 1.2899,-0.8590)
 2  ( 0.3397,-1.5006) ( 1.5201,-0.4301) ( 1.8797,-5.3804) ( 3.3606, 0.6498)
 3  ( 3.3101,-3.8506) ( 2.4996, 3.4504) ( 0.8802,-1.0802) ( 0.6401,-1.4800)
 4  (-1.0999, 0.8199) ( 1.8103,-1.5905) ( 3.2502, 1.3297) ( 1.5701,-3.4397)

 Condition number estimate of the selected cluster of eigenvalues =   1.02E+00

 Condition number estimate of the specified invariant subspace    =   1.82E-01
