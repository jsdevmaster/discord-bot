 ZSPCON Example Program Results

 Estimate of condition number =  2.06E+01
