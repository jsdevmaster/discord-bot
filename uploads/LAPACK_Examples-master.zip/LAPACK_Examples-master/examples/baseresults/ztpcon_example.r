 ZTPCON Example Program Results

 Estimate of condition number =  3.74E+01
