 DGBCON Example Program Results

 Estimate of condition number =  5.64E+01
