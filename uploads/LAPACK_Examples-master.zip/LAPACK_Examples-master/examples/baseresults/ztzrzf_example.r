 ZTZRZF Example Program Results

 Tolerance used to estimate the rank of A
      1.00E-02
 Estimated rank of A
      3

 Least squares solution(s)
                    1                 2
 1  ( 1.1669,-3.3224) (-0.5023, 1.8323)
 2  ( 1.3486, 5.5027) (-1.4418,-1.6465)
 3  ( 4.1764, 2.3435) ( 0.2908, 1.4900)
 4  ( 0.6467, 0.0107) (-0.2453, 0.3951)

 Square root(s) of the residual sum(s) of squares
      2.51E-01   8.10E-02
