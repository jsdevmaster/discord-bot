 DGELSS Example Program Results

 Least squares solution
      0.6344     0.9699    -1.4403     3.3678     3.3992

 Tolerance used to estimate the rank of A
      1.00E-02
 Estimated rank of A
      4

 Singular values of A
      3.9997     2.9962     2.0001     0.9988     0.0025
