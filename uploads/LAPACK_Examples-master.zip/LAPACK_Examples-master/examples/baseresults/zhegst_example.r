 ZHEGST Example Program Results

 Eigenvalues
    -5.9990 -2.9936  0.5047  3.9990
