 ZTRRFS Example Program Results

 Solution(s)
                    1                 2
 1  (-5.0000,-2.0000) ( 1.0000, 5.0000)
 2  (-3.0000,-1.0000) (-2.0000,-2.0000)
 3  ( 2.0000, 1.0000) ( 3.0000, 4.0000)
 4  ( 4.0000, 3.0000) ( 4.0000,-3.0000)

 Backward errors (machine-dependent)
         1.2E-16           5.5E-17
 Estimated forward error bounds (machine-dependent)
         3.0E-14           3.3E-14
