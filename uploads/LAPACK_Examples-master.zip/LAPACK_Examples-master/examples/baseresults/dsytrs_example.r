 DSYTRS Example Program Results

 Solution(s)
             1          2
 1     -4.0000     1.0000
 2     -1.0000     4.0000
 3      2.0000     3.0000
 4      5.0000     2.0000
