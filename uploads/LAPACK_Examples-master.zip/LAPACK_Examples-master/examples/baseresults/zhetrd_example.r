 ZHETRD Example Program Results

 Diagonal and off-diagonal elements of tridiagonal form

     i         D            E
     1     -2.28000      4.33846
     2     -0.12846      2.02259
     3     -0.16659      1.80232
     4     -1.92495
