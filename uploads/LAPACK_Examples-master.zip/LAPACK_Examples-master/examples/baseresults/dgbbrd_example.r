 DGBBRD Example Program Results

 Diagonal D:
         3.0561        1.5259        0.9690        1.5685

 Off-diagonal E:
         0.6206        1.2353        1.1240
