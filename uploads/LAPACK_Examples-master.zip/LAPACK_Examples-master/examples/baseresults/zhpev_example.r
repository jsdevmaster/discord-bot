 ZHPEV Example Program Results

 Eigenvalues
    -4.2443 -0.6886  1.1412 13.7916

 Error estimate for the eigenvalues
        3.1E-15
