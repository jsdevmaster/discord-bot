 ZHEEVR Example Program Results

 Selected eigenvalues
    -0.6886  1.1412
 Selected eigenvectors
          1       2
 1   0.6470  0.0179
     0.0000 -0.4453
 
 2  -0.4984  0.5706
    -0.1130 -0.0000
 
 3   0.2949 -0.1530
     0.3165  0.5273
 
 4  -0.2241 -0.2118
    -0.2878 -0.3598
