 ZHEGV Example Program Results

 Eigenvalues
       -5.9990    -2.9936     0.5047     3.9990
 Eigenvectors
             1          2          3          4
 1      1.7405    -0.6626     0.2835     1.2378
        0.0000     0.2258    -0.5806     0.0000
 
 2     -0.4136    -0.1164    -0.3769    -0.5608
       -0.4689    -0.0178    -0.3194    -0.3729
 
 3     -0.8404     0.9098    -0.3338    -0.6643
       -0.2483     0.0000    -0.0134    -0.1021
 
 4      0.3021    -0.6120     0.6663     0.1589
        0.6103    -0.5348     0.0000     0.8366

 Estimate of reciprocal condition number for B
        2.5E-03

 Error estimates for the eigenvalues
        6.7E-13    4.1E-13    1.9E-13    5.0E-13

 Error estimates for the eigenvectors
        1.2E-12    1.1E-12    8.5E-13    9.4E-13
