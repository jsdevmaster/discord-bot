 DSYEV Example Program Results

 Eigenvalues
    -2.0531 -0.5146 -0.2943 12.8621
 Eigenvectors
          1       2       3       4
 1   0.7003 -0.5144 -0.2767  0.4103
 2   0.3592  0.4851  0.6634  0.4422
 3  -0.1569  0.5420 -0.6504  0.5085
 4  -0.5965 -0.4543  0.2457  0.6144

 Error estimate for the eigenvalues
        2.9E-15

 Error estimates for the eigenvectors
        1.9E-15    1.3E-14    1.3E-14    2.2E-16
