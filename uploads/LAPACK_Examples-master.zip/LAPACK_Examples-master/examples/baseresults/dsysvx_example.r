 DSYSVX Example Program Results

 Solution(s)
             1          2
 1     -5.0000     2.0000
 2     -2.0000     3.0000
 3      1.0000     4.0000
 4      4.0000     1.0000

 Backward errors (machine-dependent)
       1.4E-16    1.0E-16

 Estimated forward error bounds (machine-dependent)
       2.5E-14    3.2E-14

 Estimate of reciprocal condition number
       1.3E-02

