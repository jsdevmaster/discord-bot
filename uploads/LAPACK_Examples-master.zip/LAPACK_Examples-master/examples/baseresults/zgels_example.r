 ZGELS Example Program Results

 Least squares solution
 (-0.5044,-1.2179) (-2.4281, 2.8574) ( 1.4872,-2.1955) ( 0.4537, 2.6904)

 Square root of the residual sum of squares
   6.88E-02
