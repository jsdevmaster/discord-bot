 DGECON Example Program Results

 Estimate of condition number =  1.52E+02
