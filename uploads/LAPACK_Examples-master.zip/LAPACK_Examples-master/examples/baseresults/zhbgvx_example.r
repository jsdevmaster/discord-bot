 ZHBGVX Example Program Results

 Number of eigenvalues found =    2

 Eigenvalues
     0.1603  1.7712
 Selected eigenvectors
             1          2
 1      0.1908     0.0494
        0.0137    -0.0045
 
 2      0.1413     0.2505
        0.1012     0.4427
 
 3     -0.0437    -0.9705
       -0.0905     0.0679
 
 4     -0.2135     0.0606
        0.2880    -1.3227
