 ZTRSNA Example Program Results

 S
       9.9E-01    1.0E+00    9.8E-01    9.8E-01

 SEP
       8.4E+00    8.0E+00    5.8E+00    5.8E+00

 Approximate error estimates for eigenvalues of T (machine-dependent)
       2.1E-15    2.1E-15    2.1E-15    2.1E-15

 Approximate error estimates for right eigenvectors of T (machine-dependent)
       2.5E-16    2.6E-16    3.5E-16    3.5E-16
