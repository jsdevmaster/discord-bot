 ZPOSVX Example Program Results

 Solution(s)
                    1                 2
 1  ( 1.0000,-1.0000) (-1.0000, 2.0000)
 2  (-0.0000, 3.0000) ( 3.0000,-4.0000)
 3  (-4.0000,-5.0000) (-2.0000, 3.0000)
 4  ( 2.0000, 1.0000) ( 4.0000,-5.0000)

 Backward errors (machine-dependent)
       1.1E-16    5.3E-17

 Estimated forward error bounds (machine-dependent)
       6.0E-14    7.2E-14

 Estimate of reciprocal condition number
       6.6E-03

 A has not been equilibrated
