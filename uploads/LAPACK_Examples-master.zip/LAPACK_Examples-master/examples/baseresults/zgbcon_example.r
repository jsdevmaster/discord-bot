 ZGBCON Example Program Results

 Estimate of condition number =  1.04E+02
