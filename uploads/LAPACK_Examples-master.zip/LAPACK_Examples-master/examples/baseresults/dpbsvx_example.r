 DPBSVX Example Program Results

 Solution(s)
             1          2
 1      5.0000    -2.0000
 2     -2.0000     6.0000
 3     -3.0000    -1.0000
 4      1.0000     4.0000

 Backward errors (machine-dependent)
       8.6E-17    1.1E-16

 Estimated forward error bounds (machine-dependent)
       2.0E-14    2.8E-14

 Estimate of reciprocal condition number
       1.3E-02

 A has not been equilibrated
