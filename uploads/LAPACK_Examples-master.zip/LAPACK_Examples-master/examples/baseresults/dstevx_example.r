 DSTEVX Example Program Results

 Number of eigenvalues found =    2

 Eigenvalues
     0.6476  3.5470
 Selected eigenvectors
          1       2
 1   0.9396  0.3388
 2  -0.3311  0.8628
 3   0.0853 -0.3648
 4  -0.0167  0.0879
