 DGELSD Example Program Results

 Least squares solution
      1.5938    -0.1180    -3.1501     0.1554     2.5529    -1.6730

 Tolerance used to estimate the rank of A
      1.00E-02
 Estimated rank of A
      4

 Singular values of A
      3.9997     2.9962     2.0001     0.9988     0.0025
