 DPOCON Example Program Results

 Estimate of condition number =  9.73E+01
