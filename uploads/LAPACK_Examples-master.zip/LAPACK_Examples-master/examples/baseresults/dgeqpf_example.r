 DGEQPF Example Program Results

 Least squares solution
          1       2
 1  -0.0370 -0.0044
 2   0.0647 -0.0335
 3   0.0000  0.0000
 4  -0.0515  0.0018
 5   0.0066  0.0102
