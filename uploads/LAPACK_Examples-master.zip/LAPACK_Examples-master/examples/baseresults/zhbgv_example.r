 ZHBGV Example Program Results

 Eigenvalues
       -6.6089    -2.0416     0.1603     1.7712
