 ZGBBRD Example Program Results

 Diagonal
    2.6560   1.7501   2.0607   0.8658
 Superdiagonal
    1.7033   1.2800   0.1467
