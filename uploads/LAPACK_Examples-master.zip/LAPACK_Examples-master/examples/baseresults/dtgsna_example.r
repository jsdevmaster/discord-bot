 DTGSNA Example Program Results

 S
       1.6E+00    1.7E+00    1.7E+00    1.4E+00

 DIF
       5.4E-01    1.5E-01    1.5E-01    1.2E-01

 Approximate error estimates for eigenvalues of (A,B)
       1.7E-15    1.6E-15    1.6E-15    2.0E-15

 Approximate error estimates for right eigenvectors of (A,B)
       5.0E-15    1.8E-14    1.8E-14    2.2E-14
