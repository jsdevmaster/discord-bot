 DTBCON Example Program Results

 Estimate of condition number =  6.96E+01
