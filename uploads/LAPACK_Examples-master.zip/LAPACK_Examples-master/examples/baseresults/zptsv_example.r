 ZPTSV Example Program Results

 Solution
 (  2.0000,  1.0000) (  1.0000,  1.0000) (  1.0000, -2.0000) (  1.0000, -1.0000)

 Diagonal elements of the diagonal matrix D
  16.0000            9.0000            1.0000            4.0000

 Subdiagonal elements of the Cholesky factor L
 (  1.0000,  1.0000) (  2.0000, -1.0000) (  1.0000, -4.0000)
